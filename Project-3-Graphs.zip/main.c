//Aymane Bokhamy 96569
// Amine Elidrissi 93085
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdbool.h>
#include <limits.h>
#define infinity 9999
#define undefined -1

typedef struct {
  char id[50];
  double x, y;
} data;

typedef struct node_{
  data vertex;
  double cost;
  struct node_ * next;
}node;

typedef struct{
  node *adjlist[20];
} graph;

typedef struct{
  int s, d;
  double cost;
}mstegd;

double pathcost;
int n, range;






graph * create_graph( FILE * inp);
int getindex( graph * g, char * id);
double distance( data v1, data v2);
void link( graph * g);
void add_cost(graph * g);
int iffound( graph * g, char * id);
void sort_graph(graph * g);
void sort( node * v);
void swap( node * n1, node * n2);
void display_graph(graph* g);
void print_adj( graph * g, char * id);
void menu(void);
void add_vehicule( graph * g,  data vertex);
void delete_vehicule( graph * g, char * id);
void add_edge( graph * g, char * v1, char * v2);
void DFS(graph * g, int i);
void BFS(graph * g, char * id);
void move_vehicle( graph * g, data vertex);
node * createnode( data vertex);
void enqueue(int i);
void dequeue();
int isempty();
void get_mst_edges(graph * g);
void dijkstra( graph * g, char* source, char* dest);
void display_MST(graph * g, int * a, double edges[50][50]);
void delete_edge(graph * g, char * source, char* dest);
int minValue(int * value, bool * mspanningt) ;
void pMST( graph * g);
void display_path(graph * g, int source,int destination);




node * createnode( data vertex);


int main(void){
FILE * inp = fopen( "data.txt", "r");
  graph * g = create_graph(inp);
  link(g);
  data v;
  char  v1[20],  v2[20];
  int choice, j, k;
  char c;
  do{
    
    menu();
    scanf("%d", &choice);
    add_cost(g);
    sort_graph(g);
    switch( choice){
      case 1:
        display_graph(g);
        printf("\n\t\t\tTap Any Key To Continue...\n");
        scanf("%c", &c);
        getchar();
        break;
      case 2:
        printf("\nEnter the vehicle id\t:\t");
        scanf(" %[^\n]", v.id);
        if( iffound(g, v.id)==1)
          print_adj( g, v.id);
        else printf("\t\t\tNOT found Vehicle\n");
        printf("\n\t\t\tTap Any Key To Continue...\n");
        scanf("%c", &c);
        getchar();
        break;
      case 3:
        printf("\nEnter the id and ( x, y) coordinates of the new vehicle\t:\n");
        printf("\tId\t:\t"); scanf(" %[^\n]", v.id);
        printf("\tX\t:\t"); scanf("%lf", &v.x);
        printf("\tY\t:\t"); scanf("%lf", &v.y);
        if( iffound(g, v.id)==0){
          add_vehicule( g, v);
          add_cost(g);
          print_adj(g, v.id);
        }
        else printf("\t\t\tAlready existing Vehicle\n");
        printf("\n\t\t\tTap Any Key To Continue...\n");
        scanf("%c", &c);
        getchar();
        break;
      case 4:
        printf("\nEnter the vehicle id to be deleted\t:\t");
        scanf(" %[^\n]", v.id);
        if ( iffound(g, v.id)==1)
        delete_vehicule(g, v.id);
        else printf("\t\t\tNOT found Vehicle\n"); 
        printf("\n\t\t\tTap Any Key To Continue...\n");
        scanf("%c", &c);
        getchar();
        break;
      case 5:
        printf("\nEnter source and destination of the edge to be deleted\t:\n");
        printf("\tEnter source vehicle id\t:\t"); scanf(" %s", v1);
        printf("\tEnter destination vehicle id\t:\t"); scanf(" %s", v2);
        if( iffound(g, v1)==1 && iffound(g, v2)==1){
            delete_edge( g, v1, v2);
            delete_edge( g, v2, v1);
        }
        else printf("\t\t\tNOT found edge\n");
      
        printf("\n\t\t\tTap Any Key To Continue...\n");
        scanf("%c", &c);
        getchar();
        break;
      case 6:
        printf("\nEnter id of the vehicle to be moved\t:\t"); scanf(" %s", v.id);
        printf("\tNew X\t:\t"); scanf("%lf", &v.x);
        printf("\tNew Y\t:\t"); scanf("%lf", &v.y);
        if( iffound(g, v.id)==1){
          move_vehicle(g, v);
          link(g);
        }
        else printf("\t\t\tNOT found Vehicle\n");
        printf("\n\t\t\tTap Any Key To Continue...\n");
        scanf("%c", &c);
        getchar();
        break;
      case 7:
        printf("\nEnter the starting vehicle\t:\t"); scanf(" %s", v1);
        if( iffound(g, v1)==1){
          k = getindex(g, v1);
          DFS(g, k);
        }
        else printf("\t\t\tNOT found Vehicle\n");
        printf("\n\t\t\tTap Any Key To Continue...\n");
        scanf("%c", &c);
        getchar();
        break;
      case 8:
        printf("\nEnter the starting vehicle\t:\t"); scanf(" %s", v1);
        if( iffound(g, v1)==1)
        BFS(g, v1);
        else printf("\t\t\tNOT found Vehicle\n");
        printf("\n\t\t\tTap Any Key To Continue...\n");
        scanf("%c", &c);
        getchar();
        break;
      case 9:
        get_mst_edges(g);
        pMST( g);
        printf("\n");
        printf("\n\t\t\tTap Any Key To Continue...\n");
        scanf("%c", &c);
        getchar();
        break;
      case 10:
        printf("\nEnter the starting vehicle\t:\t"); scanf(" %s", v1);
        printf("\nEnter the ending vehicle\t:\t"); scanf(" %s", v2);
        if( iffound(g, v1)==1 && iffound(g, v2) == 1){
          dijkstra(g , v1, v2);
          j = getindex(g, v1);
          k = getindex(g, v2);
          display_path(g, j, k );
          printf("Pathg cost\t=\t%.2lf", pathcost);
        }
        else printf("\t\t\tNOT found Vehicle\n");   
        printf("\n\t\t\tTap Any Key To Continue...\n");
        scanf("%c", &c);
        getchar();
        break;
      case 11:
        printf("\t\t\tExit\n");
        printf("\n\t\t\tTap Any Key To Exit...\n");
        scanf("%c", &c);
        getchar();       
        break;
      default:
        printf("Wrong input\n");
        printf("\n\t\t\tTap Any Key To continue...\n");
        scanf("%c", &c);
        getchar();
        break;
      
    }
    //

  }while( choice != 11);

}
graph * create_graph( FILE * inp){
  int i;
  fscanf( inp, "%d\n", &n);
  fscanf( inp, "%d\n", &range);
  graph * temp = ( graph *) malloc(sizeof( graph));
  for( i = 0; i < n; i++){
    temp->adjlist[i] = ( node *)malloc( sizeof(node));
    data vertex;
     fscanf(inp," %s %lf %lf",vertex.id,&vertex.x,&vertex.y);
     temp->adjlist[i] = createnode(vertex);
     temp->adjlist[i]->cost = 0;
  }
  return temp;
}

node * createnode( data vertex){
  node * w = ( node *) malloc(sizeof( node));
  w->vertex = vertex;
  w->next = NULL;
  return w;
}
int getindex( graph * g, char * id){
  int j;
  for( int i = 0; i < n; i++){
    if( strcmp( id, g->adjlist[i]->vertex.id) == 0)
      j=i;
  }
  return j;
}

double distance( data v1, data v2){
  double res, a ,b;
  a = pow( v2.x - v1.x, 2);
  b = pow( v2.y - v1.y, 2);
  res = sqrt(a+b);
  return res;
}
void link( graph * g){
  for( int i = 0; i < n; i ++){
    node * h = g->adjlist[i];
    for( int j = 0; j < n; j++){
      node * p = g->adjlist[j];
      double res = distance( p->vertex, h->vertex);
      if( res <= range && j != i){
        node * temp = createnode(p->vertex);
        h->next = temp;
        h = h->next; 
      }
    }
  }
}
void add_cost(graph * g) { 
    int v; 
    for (v = 0; v < n; ++v) 
    { 
        node* p = g->adjlist[v]->next; 
        while (p!=NULL) 
        {   
            p->cost = distance(g->adjlist[v]->vertex, p->vertex);
            p = p->next; 
        } 
    } 
}


void swap( node * n1, node * n2){
  data temp = n1->vertex;
  n1->vertex = n2->vertex;
  n2->vertex = temp;
  double val = n1->cost;
  n1->cost = n2->cost;
  n2->cost = val;
}

void sort( node * v){
  node * walker1, * walker2;
  for ( walker1 = v; walker1 != NULL; walker1 = walker1->next){
    for( walker2 = v; walker2 != NULL; walker2 = walker2->next){
      if( walker1->cost > walker2->cost ) swap(walker1, walker2);
    }
  }
}

void sort_graph(graph * g){
  for( int i = 0; i < n; i++){
    sort( g->adjlist[i]);
  }
}

void display_graph(graph* g) { 
    int i; 
    for (i = 0; i < n; i++) 
    { 
        node* p = g->adjlist[i]->next; 
        while (p) 
        {   
            p->cost = distance(g->adjlist[i]->vertex, p->vertex);
            printf("( %s, %s, %.2lf) \n", g->adjlist[i]->vertex.id , p->vertex.id, p->cost); 
            p = p->next; 
        } 
    } 
}

void print_adj( graph * g, char * id){
  for( int  i = 0; i < n; i ++){
    if( strcmp( g->adjlist[i]->vertex.id , id) == 0){
      printf("adjacent vertexes of %s\t:\t", id);
      node * walker =  g->adjlist[i]->next;
      while( walker != NULL){
        printf("%s\t", walker->vertex.id);
        walker = walker->next;
      }
    }
  }
}

void add_vehicule( graph * g,  data vertex){
  node * temp = createnode(vertex);
  g->adjlist[n++] = temp;
  link(g); 
}

void delete_vehicule( graph * g, char * id){
  for( int  i = 0; i < n; i ++){
    if( strcmp( g->adjlist[i]->vertex.id , id) == 0){
      for (int c = i ; c < n ; c++)
         g->adjlist[c] = g->adjlist[c+1];
           n--;
  link(g);
  return;
    }
  }
}

void add_edge( graph * g, char * v1, char * v2){
  int src_index, dst_index;
  src_index = getindex(g, v1);
  dst_index = getindex(g, v2);
  node *  temp = g->adjlist[dst_index];
  node * new_node = createnode(g->adjlist[src_index]->vertex);
  while(temp != NULL && temp->next != NULL)
    temp = temp->next;
  temp->next = new_node;
  new_node = createnode(g->adjlist[dst_index]->vertex);
  temp = g->adjlist[src_index];
  while(temp != NULL && temp->next != NULL)
    temp = temp->next;
  temp->next = new_node;
}

void delete_edge(graph * g, char * source, char* dest){
int si, di;

  si = getindex(g, source);
  di = getindex(g, dest);

node *edge1 = g->adjlist[si]; 
while(edge1 != NULL && edge1->next != NULL){
  if(strcmp(edge1->vertex.id, source) == 0){
      edge1->vertex = edge1->next->vertex;
      edge1->next = edge1->next->next;
      return;
    }
  edge1 = edge1->next;
}
 
node *edge2 = g->adjlist[di]; 
while(edge2 != NULL && edge2->next != NULL == 0){
  if(strcmp(edge2->vertex.id, dest) == 0){
      edge2->vertex = edge2->next->vertex;
      edge2->next = edge2->next->next;
      return;
  }
  edge2 = edge2->next;
}
node* t = g->adjlist[si];
while (t->next != edge1) t = t->next;
t->next = NULL;

 t = g->adjlist[di];
while (t->next != edge2) t = t->next;
t->next = NULL;
}

void move_vehicle( graph * g, data vertex){
    for( int i = 0; i < n; i ++){
        if( strcmp( g->adjlist[i]->vertex.id , vertex.id) == 0){
        delete_vehicule(g, vertex.id);
        add_vehicule(g, vertex);
        link(g);            
        return;
    }
    }
    return;
}

int visited[50];
int queue[20];
int front = 0, r = -1;
void enqueue(int i){
    queue[++r] = i ;
}
void dequeue(){
    front++;
}
int isempty(){
  if(front > r)
    return 1;
  else
    return 0;
}

void BFS(graph * g, char * id){
 int i,j,x;
    node *a, *w;
      for( i = 0; i < n ; i++){
         visited[j] = 0;
        }
      j = getindex(g, id);
    printf ("%s",g->adjlist[j]->vertex.id);
    visited[j] = 1;
    enqueue(j);
    while( !isempty() ){
      a = g->adjlist[queue[front]];
      dequeue();
      for(w=a; w != NULL;w = w->next){
          i = getindex(g, w->vertex.id);
        if(!visited[j]){
          printf("\t%s",w->vertex.id);
          enqueue(i);
          visited[j] = 1;
       }
     }
 }
}
void DFS(graph * g, int i){
  node *a;
  a=g->adjlist[i];
  visited[i]=1;
  printf("%s\t",g->adjlist[i]->vertex.id);
  while(a!=NULL)
    {
      i = getindex(g, a->vertex.id);
       
	   if(!visited[i]){
            DFS(g, i);
     }
     
        a = a ->next;
    }
    printf("\n");
}

double edges[50][50];
void get_mst_edges(graph * g){
  int a;
    for( int i = 0; i < n; i++){
      for( node * walker = g->adjlist[i]; walker != NULL; walker = walker->next){
            a = getindex(g, walker->vertex.id);
             if( walker->cost != 0)
                edges[i][a] = walker->cost;
      }
    }
}


void display_MST(graph * g, int * a, double edges[50][50]) { 
    int b ;
    double cost = 0;
    printf("Edge \t\tWeight\n"); 
    for (int i = 1; i < n; i++) 
        if( edges[i][a[i]] != 0){
          b = a[i];
          printf("%s - %s \t%lf \n", g->adjlist[b]->vertex.id , g->adjlist[i]->vertex.id , edges[i][a[i]]); 
          cost += edges[i][a[i]];
        }
    printf("The cost of the Minimum Spanning Tree\t:\t%.2lf\n", cost);     
} 

int visited1[50],path[20];
double dist[20],costdijkstra=0;
void dijkstra( graph * g, char* source, char* dest){
    int i,source_index,destination_index,j,min=999,minimum;
    node *walker,*point;

        source_index=getindex(g, source);
        destination_index=getindex(g, dest);
            for(i=0;i<n;i++){
                  dist[i]=infinity;
                  path[i]= undefined;
                  visited1[i]=0;
               }
             visited1[source_index]=1;
             dist[source_index]=0;
        for(walker=g->adjlist[source_index];walker!=NULL;walker=walker->next){
            dist[getindex(g, walker->vertex.id)]= walker->cost;
            path[getindex(g, walker->vertex.id)]=source_index; 
          }
     do{
        min=infinity;
        for(j=0;j<n;j++)
            if(visited1[j]==0 && dist[j] < min) {
                 min=dist[j];
                minimum=j;
               }
        visited1[minimum]=1;
            for(point=g->adjlist[minimum]; point!=NULL;point=point->next){
                if(visited1[getindex(g, point->vertex.id)]==0 && ( (dist[minimum] + distance(g->adjlist[minimum]->vertex,g->adjlist[getindex(g, point->vertex.id)]->vertex ) ) < dist[getindex(g, point->vertex.id)]))
                {
                dist[getindex(g, point->vertex.id)] = dist[minimum] + distance(g->adjlist[minimum]->vertex,g->adjlist[getindex(g, point->vertex.id)]->vertex );
                 path[getindex(g, point->vertex.id)] = minimum;
                }
            } 
        }while(visited1[destination_index]!=1);
}

void display_path(graph * g, int source,int destination){
  int temp;
 
    if (source==destination)
      return;
    else{
        temp=path[destination];
        display_path(g, source,temp);
        printf("\t\t\t%s -> %s %.2f\n\n",g->adjlist[temp]->vertex.id,g->adjlist[destination]->vertex.id, distance(g->adjlist[destination]->vertex,g->adjlist[temp]->vertex));
        costdijkstra +=  distance(g->adjlist[destination]->vertex,g->adjlist[temp]->vertex);
        }
        pathcost = costdijkstra;
}
int iffound( graph * g, char * id){
  for( int i = 0; i < n; i ++){
    if( strcmp(g->adjlist[i]->vertex.id, id) == 0)
      return  1;
  }
  return 0;
}

void menu(void){
    printf("\t1. Display all edges \n");
    printf("\t2. Display adjacent vehicles\n");
    printf("\t3. Add a Vehicle\n");
    printf("\t4. Delete a Vehicle by vehicleID\n");
    printf("\t5. Delete an Edge\n");
    printf("\t6. Move a Vehicle\n");
    printf("\t7. Depth First Search (DFS)\n");
    printf("\t8. Breadth First Search (BFS)\n");
    printf("\t9. Minimum Spanning Tree\n");
    printf("\t10. Shortest Path between 2 vehicles \n");
    printf("\t11. Quit\n");

    printf("\n\tYour choice :  ");
return;
}
int minValue(int * value, bool * mspanningt) { 
    int min = INT_MAX, minindex; 
    for (int i = 0; i < n; i++)
        if (mspanningt[i] == false && value[i] < min) 
            min = value[i], minindex = i; 
    return minindex; 
}
void pMST( graph * g){ 
    int parents[20];  
    int value[20]; 
    bool mstSet[20]; 
    for(int i = 0; i < n; i++) 
        value[i] = INT_MAX, mstSet[i] = false; 
    value[0] = 0; 
    parents[0] = -1;
    for (int j = 0; j < n - 1; j++) { 
        int x = minValue(value, mstSet); 
        mstSet[x] = true; 
        for (int k = 0; k < n; k++) 
            if (edges[x][k] && mstSet[k] == false && edges[x][k] < value[k]) 
                parents[x] = x, value[k] = edges[x][k]; 
    } 
    display_MST(g, parents, edges); 
}